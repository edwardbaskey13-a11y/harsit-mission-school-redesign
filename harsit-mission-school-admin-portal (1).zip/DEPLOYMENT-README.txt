HARSIT MISSION SCHOOL — REDESIGNED WEBSITE

Files
- index.html: redesigned school website and three-step admission enquiry
- styles.css: responsive premium visual system
- script.js: navigation, gallery and admission wizard interactions
- images/: original school image assets retained
- cloud-config.js / cloud-public.js: existing optional public Supabase content sync retained

DEPLOYMENT
1. Upload this project folder to the connected GitHub repository (or deploy this folder to Netlify).
2. In Netlify, open Forms and ensure form detection is enabled. Trigger a fresh deploy after enabling form detection.
3. Submit one test admission enquiry and confirm it appears in Netlify Forms > admission-enquiry.
4. Configure form notification emails in Netlify so the school office receives new enquiries.
5. The campus visit date/time is a requested preference, not a confirmed appointment. The school must contact the parent to confirm it.

IMPORTANT
- The form uses Netlify Forms. It will only save enquiries after deployment to a Netlify site with form detection enabled.
- The reference number is generated in the browser for the parent's confirmation and is included in the submitted form data; it is not a server-issued application ID.
- No payment gateway, official online payment collection, or final admission decision has been fabricated.
- Existing school facts, contact details, address, leadership names, curriculum wording and original photos were retained from the supplied source. Verify them with the school before production launch.
- cloud-config.js contains empty Supabase public settings in the supplied source. Do not place a Supabase service-role key or other secret in browser files.


ADMIN PORTAL ADDITION (NEW)
- Open /admin/ on the deployed site to access the staff portal.
- Admin portal uses Supabase Auth email OTP and the existing staff_profiles / admission_enquiries tables.
- cloud-config.js now contains the supplied Supabase Project URL and browser-safe publishable key.
- The admin portal calls signInWithOtp with shouldCreateUser:false and checks the signed-in user's active staff_profiles row before showing any dashboard data.
- RLS must remain enabled. Never add a service_role or sb_secret key to browser files or GitHub.
- Deploy the full folder, including the new admin/ directory and updated cloud-config.js, to the existing Netlify site.

IMPORTANT DATA INTEGRATION LIMITATION
- Netlify Forms submissions are NOT automatically inserted into Supabase by this front-end.
- Until a secure server-side Netlify Forms -> Supabase integration is configured, the dashboard may show zero enquiries even though Netlify Forms has submissions.
- The next development step after deploying and testing OTP login is to add a Netlify Function / verified server-side form webhook. The Supabase service-role secret must be stored only in Netlify environment variables, never in browser code or GitHub.
- This package does not expose public insert permissions and does not bypass the database RLS policies.
