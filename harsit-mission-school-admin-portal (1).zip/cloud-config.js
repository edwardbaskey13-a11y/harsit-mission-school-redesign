/*
  Harsit Mission School — Supabase public client configuration.
  The publishable key is designed for browser use. Keep RLS enabled.
  NEVER put a Supabase secret/service_role key in this file.
*/
window.HMS_SUPABASE_URL = 'https://rajtwetxwunodzuldimw.supabase.co';
window.HMS_SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_QDdvER0AHawGyd8l49Fw2g_aWhsfcRd';
// Backward-compatible alias used by the existing optional public content script.
window.HMS_SUPABASE_ANON_KEY = window.HMS_SUPABASE_PUBLISHABLE_KEY;
