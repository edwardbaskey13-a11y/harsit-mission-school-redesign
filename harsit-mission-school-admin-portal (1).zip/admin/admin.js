(() => {
  const $ = id => document.getElementById(id);
  const cfg = window.HMS_SUPABASE_URL && window.HMS_SUPABASE_PUBLISHABLE_KEY;
  if (!cfg || !window.supabase) {
    $('loginFeedback').textContent = 'Supabase configuration or client library is missing. Check the project connection settings.';
    return;
  }
  const client = window.supabase.createClient(window.HMS_SUPABASE_URL, window.HMS_SUPABASE_PUBLISHABLE_KEY, {
    auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
  });
  let currentUser = null, currentProfile = null, records = [], selected = null, emailForOtp = '';

  const statusLabel = s => ({new:'New',contacted:'Contacted',visit_scheduled:'Visit scheduled',application_received:'Application received',admitted:'Admitted',not_admitted:'Not admitted',withdrawn:'Withdrawn'}[s] || s);
  const safe = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const date = v => v ? new Date(v).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'}) : '—';
  function feedback(id,msg,ok=false){const el=$(id);el.textContent=msg;el.classList.toggle('ok',ok);}
  function showLogin(){ $('loginPanel').hidden=false; $('dashboard').hidden=true; }
  function showDashboard(){ $('loginPanel').hidden=true; $('dashboard').hidden=false; $('signedInAs').textContent=`${currentUser.email} · ${currentProfile.role==='super_admin'?'Super Admin':'Admission Staff'}`; }

  $('emailForm').addEventListener('submit', async e => {
    e.preventDefault(); emailForOtp=$('email').value.trim().toLowerCase();
    $('sendCodeBtn').disabled=true; feedback('loginFeedback','Sending your secure code…');
    const {error}=await client.auth.signInWithOtp({email:emailForOtp,options:{shouldCreateUser:false}});
    $('sendCodeBtn').disabled=false;
    if(error){feedback('loginFeedback',error.message);return;}
    $('emailForm').hidden=true;$('otpForm').hidden=false;$('loginStepLabel').textContent='EMAIL VERIFICATION';$('loginHeading').textContent='Check your inbox';$('loginHelp').textContent=`Enter the six-digit code sent to ${emailForOtp}.`;feedback('loginFeedback','Verification code sent. Check your inbox and spam folder.',true);
  });
  $('backBtn').addEventListener('click',()=>{$('otpForm').hidden=true;$('emailForm').hidden=false;$('otp').value='';$('loginStepLabel').textContent='STAFF EMAIL';$('loginHeading').textContent='Sign in';$('loginHelp').textContent='Enter your approved staff email address to receive a one-time code.';feedback('loginFeedback','');});
  $('otpForm').addEventListener('submit',async e=>{
    e.preventDefault();const token=$('otp').value.trim();if(!/^\d{6}$/.test(token)){feedback('loginFeedback','Enter the six-digit code from your email.');return;}
    $('verifyBtn').disabled=true;feedback('loginFeedback','Verifying code…');
    const {data,error}=await client.auth.verifyOtp({email:emailForOtp,token,type:'email'});
    $('verifyBtn').disabled=false;
    if(error){feedback('loginFeedback',error.message);return;}
    await authorize(data.user);
  });
  async function authorize(user){
    const {data,error}=await client.from('staff_profiles').select('user_id,email,role,is_active').eq('user_id',user.id).maybeSingle();
    if(error || !data || !data.is_active || !['super_admin','admission_staff'].includes(data.role)){
      await client.auth.signOut();feedback('loginFeedback','This account is not authorized for the school admin portal. Contact the Super Admin.');return;
    }
    currentUser=user;currentProfile=data;showDashboard();await loadEnquiries();
  }
  async function restore(){
    const {data:{session}}=await client.auth.getSession();
    if(session?.user) await authorize(session.user); else showLogin();
  }
  async function loadEnquiries(){
    $('enquiryRows').innerHTML='<tr><td colspan="6" class="empty">Loading enquiries…</td></tr>';
    const {data,error}=await client.from('admission_enquiries').select('id,enquiry_reference,student_name,date_of_birth,class_applying,academic_session,parent_name,relationship,parent_phone,parent_email,address,campus_visit_requested,preferred_visit_date,preferred_visit_time,status,staff_notes,source,created_at,updated_at').order('created_at',{ascending:false}).limit(500);
    if(error){$('enquiryRows').innerHTML=`<tr><td colspan="6" class="empty">${safe(error.message)}</td></tr>`;return;}
    records=data||[];render();
  }
  function render(){
    const term=$('searchInput').value.trim().toLowerCase(), status=$('statusFilter').value;
    const filtered=records.filter(r=>(!status||r.status===status)&&(!term||[r.enquiry_reference,r.student_name,r.parent_name,r.parent_phone,r.parent_email].some(v=>String(v||'').toLowerCase().includes(term))));
    $('totalCount').textContent=records.length;$('newCount').textContent=records.filter(r=>r.status==='new').length;$('visitCount').textContent=records.filter(r=>r.campus_visit_requested).length;$('admittedCount').textContent=records.filter(r=>r.status==='admitted').length;
    $('enquiryRows').innerHTML=filtered.length?filtered.map(r=>`<tr><td><b>${safe(r.enquiry_reference)}</b><small>${date(r.created_at)}</small></td><td><b>${safe(r.student_name)}</b><small>${safe(r.parent_email||'')}</small></td><td>${safe(r.class_applying)}</td><td><b>${safe(r.parent_name)}</b><small>${safe(r.parent_phone)}</small></td><td><span class="status ${safe(r.status)}">${safe(statusLabel(r.status))}</span></td><td><button class="row-action" data-open="${safe(r.id)}">View →</button></td></tr>`).join(''):`<tr><td colspan="6" class="empty">${records.length?'No enquiries match your search.':'No enquiries are in Supabase yet. Your Netlify Forms submissions are not automatically copied into this database.'}</td></tr>`;
    document.querySelectorAll('[data-open]').forEach(b=>b.addEventListener('click',()=>openRecord(b.dataset.open)));
  }
  function openRecord(id){
    selected=records.find(r=>r.id===id);if(!selected)return;
    $('detailTitle').textContent=selected.student_name||'Student enquiry';
    const fields=[['Reference',selected.enquiry_reference],['Date received',date(selected.created_at)],['Date of birth',date(selected.date_of_birth)],['Class applying',selected.class_applying],['Academic session',selected.academic_session],['Parent / guardian',selected.parent_name],['Relationship',selected.relationship],['Phone',selected.parent_phone],['Email',selected.parent_email],['Address',selected.address],['Campus visit requested',selected.campus_visit_requested?'Yes':'No'],['Preferred visit',selected.preferred_visit_date?`${date(selected.preferred_visit_date)} ${selected.preferred_visit_time||''}`:'—']];
    $('detailContent').innerHTML=`<div class="detail-grid">${fields.map(([k,v])=>`<div><span>${safe(k)}</span><b>${safe(v||'—')}</b></div>`).join('')}</div>`;
    $('detailStatus').value=selected.status;$('staffNotes').value=selected.staff_notes||'';$('updateFeedback').textContent='';$('drawerBackdrop').hidden=false;
  }
  $('updateForm').addEventListener('submit',async e=>{
    e.preventDefault();if(!selected)return;$('saveUpdateBtn').disabled=true;feedback('updateFeedback','Saving…');
    const {data,error}=await client.from('admission_enquiries').update({status:$('detailStatus').value,staff_notes:$('staffNotes').value}).eq('id',selected.id).select('id,status,staff_notes').maybeSingle();
    $('saveUpdateBtn').disabled=false;
    if(error){feedback('updateFeedback',error.message);return;}
    if(!data){feedback('updateFeedback','No record was updated. Check staff permissions.');return;}
    feedback('updateFeedback','Changes saved successfully.',true);await loadEnquiries();selected=records.find(r=>r.id===data.id)||null;
  });
  $('closeDrawer').addEventListener('click',()=>$('drawerBackdrop').hidden=true);
  $('drawerBackdrop').addEventListener('click',e=>{if(e.target===$('drawerBackdrop'))$('drawerBackdrop').hidden=true;});
  $('refreshBtn').addEventListener('click',loadEnquiries);
  $('searchInput').addEventListener('input',render);$('statusFilter').addEventListener('change',render);
  $('signOutBtn').addEventListener('click',async()=>{await client.auth.signOut();currentUser=null;currentProfile=null;showLogin();});
  client.auth.onAuthStateChange((event,session)=>{if(event==='SIGNED_OUT'){currentUser=null;currentProfile=null;showLogin();}});
  restore();
})();
